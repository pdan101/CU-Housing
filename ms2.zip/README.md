# CU Housing - Trends Final Project

This project is meant to help Cornell students find more information about housing in the area.

Developers:
- Cooper Murr (cbm94)
- John Tumulo (jjt96)
- Leah Liu (lsl89)
- Prithwish Dan (pd337)